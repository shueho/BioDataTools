
library(ggplot2)
library(scales)

# ====================== 自定义参数 ======================
select_line <- "median"  # 中线选择："mean" / "median"
time_scale  <- 1000000   # 时间轴缩放倍数（Myr转年常用1e6）
# ============================================================

dat <- read.delim("china.txt", header = T, sep = "\t")

dat$time_scaled <- dat$time * time_scale

dat$mid <- if(select_line == "mean") dat$mean else dat$median

y_min_val <- min(dat$lower, na.rm = TRUE)
y_max_val <- max(dat$upper, na.rm = TRUE)

min_exp <- ceiling(log10(y_min_val)) - 1
max_exp <- floor(log10(y_max_val)) + 1

y_breaks <- 10^(min_exp:max_exp)

y_labels <- sapply(min_exp:max_exp, function(e) {
  val <- 10^e
  if (e >= 0) {
    return(as.character(val))
  } else {
    return(paste0("1E", e))
  }
})

ggplot(dat, aes(x = time_scaled)) +
  geom_ribbon(aes(ymin = lower, ymax = upper), fill = "grey70", alpha = 0.4) +
  geom_line(aes(y = mid), color = "black", linewidth = 1) +
  
  scale_y_log10(
    breaks = y_breaks,
    labels = y_labels,
    limits = range(y_breaks),
    expand = c(0,0)
  ) +
  scale_x_continuous(labels = comma_format(), expand = c(0,0)) +
  
  labs(x = "Time (Years)", y = "Effective population size") +
  theme_bw() +
  theme(
    panel.grid = element_blank(),
    axis.text = element_text(size = 10),
    axis.text.x = element_text(face = "bold", colour = "black",size = 10), 
    axis.text.y = element_text(face = "bold", colour = "black",size = 10), 
    axis.title = element_text(face = "bold", size = 12, colour = "black")
  )