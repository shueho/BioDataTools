
window_size <- 100   # 窗口大小（bp）
step_size   <- 20    # 步长（bp）
input_file  <- "depth.txt"


if (!require(ggplot2)) install.packages("ggplot2")
if (!require(dplyr))   install.packages("dplyr")
library(ggplot2)
library(dplyr)

data <- read.table(input_file, header = TRUE, sep = "", stringsAsFactors = FALSE)
data <- data[order(data$Position), ]

calc_window_means <- function(df, win_size, step) {
  positions <- df$Position
  coverage  <- df$Coverage
  max_pos   <- max(positions)
  starts <- seq(from = min(positions), to = max_pos - win_size + 1, by = step)
  result <- data.frame()
  for (start in starts) {
    end <- start + win_size - 1
    idx <- which(positions >= start & positions <= end)
    if (length(idx) > 0) {
      mean_cov <- mean(coverage[idx], na.rm = TRUE)
      midpoint <- (start + end) / 2
      result <- rbind(result, 
                      data.frame(Start = start, End = end, 
                                 Midpoint = midpoint, MeanCoverage = mean_cov))
    }
  }
  return(result)
}

window_data <- calc_window_means(data, window_size, step_size)


x_max <- ceiling(max(window_data$Midpoint) / 1000) * 1000  
y_max <- max(window_data$MeanCoverage, na.rm = TRUE) * 1.2

p <- ggplot() +
  geom_area(data = window_data, aes(x = Midpoint, y = MeanCoverage),
            fill = "#00BFFF", alpha = 0.8) +
  geom_line(data = window_data, aes(x = Midpoint, y = MeanCoverage),
            color = "#0000FF", alpha = 0.8) +
  scale_x_continuous(
    breaks = seq(0, x_max, by = x_max / 20),
    limits = c(0, x_max),
    expand = expansion(mult = c(0, 0.05))
  ) +
  scale_y_continuous(
    limits = c(0, y_max),
    expand = expansion(mult = 0)
  ) +
  labs(
    y = "Mean Coverage",
    x = "Genomic Position"
  ) +
  theme_classic() +
  theme(
    text = element_text(family = "serif"),
    axis.text = element_text(family = "serif"),
    axis.title = element_text(family = "serif")
  )

ggsave("Coverage.pdf", p, width = 10, height = 5)
