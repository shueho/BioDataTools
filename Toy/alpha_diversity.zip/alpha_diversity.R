# 计数α多样性指数部分参考：https://zhuanlan.zhihu.com/p/386944776
# 计数α多样性指数部分可以引用vegan包

# 加载包
# install.packages("vegan")
# install.packages("tidyverse")

library(vegan)
library(tidyverse)

# 参数配置
otu_path     <- "merge_table.tsv"   # ASV/OTU原始计数丰度表路径
metadata_path <- "metadata.tsv"
rarefy_depth <- 0                   # 抽平深度：0=自动取最小样本reads计数；>0为指定深度，小于指定深度的样本将被删除
set.seed(123)


otu_raw <- read.csv(otu_path, row.names = 1, check.names = F,sep = "\t")
metadata <- read.csv(metadata_path, row.names = 1, check.names = F,sep = "\t")
otu_t <- t(otu_raw) %>% as.data.frame()

# 判断抽平深度
sample_sum <- rowSums(otu_t)
min_depth <- min(sample_sum)
cat("最小测序深度 =", min_depth, "\n")
if(rarefy_depth == 0){
  use_depth <- min_depth
}else{
  use_depth <- rarefy_depth
}
cat("使用抽平深度：", use_depth, "\n")
keep_samples <- sample_sum >= use_depth
otu_rare <- otu_t[keep_samples, ]
otu_rare <- rrarefy(otu_rare, sample = use_depth)
meta_rare <- metadata[rownames(otu_rare), ]


all_samples <- names(sample_sum)
removed_samples <- all_samples[!keep_samples]

sink("01.alpha_log.txt")
cat("实际使用抽平深度 use_depth: ", use_depth, "\n")
cat("\n被剔除样本列表（reads小于抽平深度）:\n")
if(length(removed_samples) > 0){
  cat(paste(removed_samples, collapse = "\n"), "\n")
}else{
  cat("无样本被剔除\n")
}
sink()

otu_rare_out <- t(otu_rare) %>% as.data.frame()
otu_rare_out <- otu_rare_out %>% rownames_to_column("ID")
write.table(otu_rare_out, file = "02.otu_rarefied.tsv", sep = "\t", row.names = F, quote = F)


alpha_diversity <- function(x) {
  observed_species <- estimateR(x)[1, ]
  Chao1 <- estimateR(x)[2, ]
  ACE <- estimateR(x)[4, ]
  Shannon <- diversity(x, index = 'shannon',base = 2)
  Simpson <- diversity(x, index = 'simpson')    #注意，这里是Gini-Simpson 指数
  goods_Coverage <- 1 - rowSums(x == 1) / rowSums(x)
  
  #保留四位小数
  Shannon <- sprintf("%0.4f", Shannon)
  Simpson <- sprintf("%0.4f", Simpson)
  goods_Coverage <- sprintf("%0.4f", goods_Coverage)
  
  
  result <- data.frame(observed_species, ACE,Chao1, Shannon, Simpson, goods_Coverage)
  result
}
alpha <- alpha_diversity (otu_rare)


alpha <- alpha %>% rownames_to_column("SampleID")
meta_rare <- meta_rare %>% rownames_to_column("SampleID")
alpha_all <- left_join(meta_rare, alpha, by = "SampleID")
write.csv(alpha_all, file = "03.alpha_diversity.csv", row.names = F)