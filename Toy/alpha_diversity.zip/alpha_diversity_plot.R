# 加载包
# install.packages("tidyverse")
# install.packages("ggpubr")
# install.packages("dunn.test")

library(tidyverse)
library(ggpubr)
library(dunn.test)

options(warn = -1)

# 参数配置
tbl_path      <- "03.alpha_diversity.csv"   # α多样性数据表路径
groupCol      <- 4                          # 分组所在列号
index_vec     <- c("observed_species", "Chao1", "ACE", "Shannon", "Simpson")
                                            # 需要绘制的多样性指数（填写表中实际列名）
control_group <- "S1"                       # 指定对照组；NA 或设置不存在的组名表示不指定
test_method   <- 2                          # 检验方法：1 = t检验/ANOVA；2 = Wilcoxon秩和检验/KW+Dunn
ncol_per_row  <- 4                          # 组合图中每行显示的图数
expand_top    <- 0.10                       # 顶部预留空白比例

colors_set <- c("#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3",
                "#A6D854", "#FFD92F", "#E5C494", "#FDB462")

alpha_all <- read.csv(tbl_path, check.names = FALSE)
group_col <- colnames(alpha_all)[groupCol]

n_groups_all <- length(unique(as.character(alpha_all[[group_col]])))
colors_set   <- rep_len(colors_set, n_groups_all)

all_groups <- unique(as.character(alpha_all[[group_col]]))
if (!is.na(control_group) && !(control_group %in% all_groups)) {
  control_group <- NA
}

alpha_long <- alpha_all %>%
  select(1, all_of(group_col), all_of(index_vec)) %>%
  pivot_longer(cols = all_of(index_vec),
               names_to = "Index", values_to = "Value")
alpha_long$Index <- factor(alpha_long$Index, levels = index_vec)

form <- as.formula(paste("Value ~", "`", group_col, "`", sep = ""))

theme_alpha <- theme_bw() +
  theme(
    legend.position = "none",
    axis.text.x = element_text(angle = 45, hjust = 1,
                               color = "black", family = "serif"),
    axis.text.y = element_text(color = "black", family = "serif"),
    axis.title.x = element_text(color = "black", family = "serif", size = 12),
    axis.title.y = element_text(color = "black", family = "serif", size = 12)
  )

plot_alpha_box <- function(dat_sub, group_col, idx,
                           colors_set, my_comparisons, test_method,
                           expand_top = 0.30) {
  p <- ggplot(dat_sub, aes(x = .data[[group_col]], y = Value,
                           fill = .data[[group_col]])) +
    geom_boxplot(alpha = 0.7, outlier.shape = NA) +
    geom_jitter(width = 0.2, size = 1) +
    scale_fill_manual(values = colors_set) +
    scale_y_continuous(expand = expansion(mult = c(0.05, expand_top))) +
    theme_alpha +
    ylab(idx) +
    xlab(group_col)
  
  if (length(my_comparisons) > 0) {
    p <- p + stat_compare_means(
      comparisons = my_comparisons,
      method      = if (test_method == 1) "t.test" else "wilcox.test",
      label       = "p.signif"
    )
  }
  p
}

run_stat_tests <- function(dat_sub, group_col, idx, test_method,
                           need_posthoc = TRUE) {
  grp   <- unique(as.character(dat_sub[[group_col]]))
  n_grp <- length(grp)
  if (n_grp < 3) return(NULL)
  
  res <- list()
  
  if (test_method == 1) {
    fit <- aov(as.formula(paste("Value ~", "`", group_col, "`", sep = "")),
               data = dat_sub)
    s   <- summary(fit)[[1]]
    res[["overall"]] <- tibble(
      Index      = idx, Test = "ANOVA", Comparison = "Overall",
      P_value    = s[1, "Pr(>F)"], Statistic = s[1, "F value"])
    
    if (need_posthoc) {
      th  <- TukeyHSD(fit)
      tbl <- as.data.frame(th[[1]])
      res[["posthoc"]] <- tibble(
        Index      = idx, Test = "TukeyHSD",
        Comparison = rownames(tbl),
        P_value    = tbl$`p adj`,
        Statistic  = tbl$`diff`)
    }
  } else {
    fit <- kruskal.test(as.formula(paste("Value ~", "`", group_col, "`", sep = "")),
                        data = dat_sub)
    res[["overall"]] <- tibble(
      Index      = idx, Test = "Kruskal-Wallis", Comparison = "Overall",
      P_value    = fit$p.value, Statistic = as.numeric(fit$statistic))
    
    if (need_posthoc) {
      dt <- dunn.test(dat_sub$Value, dat_sub[[group_col]],
                      method = "none", altp = TRUE)
      z_vals <- as.numeric(dt$Z)
      res[["posthoc"]] <- tibble(
        Index      = idx, Test = "Dunn",
        Comparison = dt$comparisons,
        P_value    = 2 * pnorm(-abs(z_vals)),
        Statistic  = z_vals)
    }
  }
  bind_rows(res)
}

stat_res_list <- list()
plot_list     <- list()

for (idx in index_vec) {
  dat_sub <- alpha_long %>% filter(Index == idx)
  grp     <- unique(as.character(dat_sub[[group_col]]))
  n_grp   <- length(grp)
  
  my_comparisons <- list()
  comp_list      <- list()
  
  has_control <- !is.na(control_group) && control_group %in% grp
  
  if (n_grp == 2) {
    pairs_to_compare <- list(grp)
    
  } else if (n_grp > 2 && has_control) {
    pairs_to_compare <- map(setdiff(grp, control_group),
                            function(g) c(control_group, g))
    overall_df <- run_stat_tests(dat_sub, group_col, idx, test_method,
                                 need_posthoc = FALSE)
    if (!is.null(overall_df)) comp_list[["overall"]] <- overall_df
    
  } else {
    pairs_to_compare <- list()
    stat_df <- run_stat_tests(dat_sub, group_col, idx, test_method,
                              need_posthoc = TRUE)
    if (!is.null(stat_df)) comp_list[["stat"]] <- stat_df
  }
  
  if (length(pairs_to_compare) > 0) {
    for (pair in pairs_to_compare) {
      sub <- dat_sub %>% filter(!!sym(group_col) %in% pair)
      sub[[group_col]] <- factor(sub[[group_col]], levels = pair)
      
      if (test_method == 1) {
        fit <- t.test(form, data = sub);       test_name <- "t-test"
      } else {
        fit <- wilcox.test(form, data = sub, exact = FALSE)
        test_name <- "Wilcoxon"
      }
      
      comp_list[[paste(pair, collapse = "vs")]] <- tibble(
        Index      = idx,
        Test       = test_name,
        Comparison = paste(pair, collapse = " vs "),
        P_value    = fit$p.value,
        Statistic  = as.numeric(fit$statistic)
      )
    }
  }
  
  if (length(comp_list) > 0) {
    comp_df <- bind_rows(comp_list)
    stat_res_list[[idx]] <- comp_df
    cat("----------", idx, "----------\n")
    print(comp_df)
  }
  
  if (length(pairs_to_compare) > 0) {
    my_comparisons <- map(pairs_to_compare, function(x) as.character(x))
  }
  
  plot_list[[idx]] <- plot_alpha_box(
    dat_sub        = dat_sub,
    group_col      = group_col,
    idx            = idx,
    colors_set     = colors_set,
    my_comparisons = my_comparisons,
    test_method    = test_method,
    expand_top     = expand_top
  )
}

if (length(stat_res_list) > 0) {
  stat_all <- bind_rows(stat_res_list)
  write.csv(stat_all, "04.alpha_stat_result.csv", row.names = FALSE)
}

nrow_auto <- ceiling(length(plot_list) / ncol_per_row)

p_all <- ggpubr::ggarrange(plotlist = plot_list,
                           ncol = ncol_per_row,
                           nrow = nrow_auto,
                           common.legend = TRUE,
                           legend = "none")

pdf("05.alpha_multi_boxplot_with_sig.pdf",
    width = ncol_per_row * 3, height = nrow_auto * 4)
print(p_all)
dev.off()