pkgs <- c("ggplot2", "vegan")
new_pkgs <- pkgs[!(pkgs %in% installed.packages()[,"Package"])]
if(length(new_pkgs) > 0) install.packages(new_pkgs)

library(ggplot2)
library(vegan)

fst_path <- "fst.txt"
env_path <- "env.txt"
r_method = "spearman"
perm_num <- 10000

raw_fst <- read.csv(fst_path, header = FALSE, sep = "\t")
trans_fst <- raw_fst / (1 - raw_fst)
mat_fst <- as.matrix(trans_fst)
dist_fst <- as.dist(mat_fst)

raw_env <- read.csv(env_path, header = TRUE, sep = "\t")
ENV=raw_env[,-1]
ENV <- scale(ENV, center=TRUE, scale=TRUE)
rownames(ENV) <- raw_env[,1]
dist_env <- vegdist(ENV,method="euclidean",binary=FALSE, diag=FALSE, upper=FALSE,na.rm = FALSE)

mantel_res <- mantel(dist_fst, dist_env, method = r_method, permutations = perm_num, na.rm = TRUE)


vec_genetic <- as.vector(dist_fst)
vec_environmental <- as.vector(dist_env)
plot_df <- data.frame(env_dist = vec_environmental, genetic_dist = vec_genetic)

x_low <- min(plot_df$env_dist, na.rm = TRUE)
x_high <- max(plot_df$env_dist, na.rm = TRUE)

p <- ggplot(plot_df, aes(x = env_dist, y = genetic_dist)) + 
  geom_smooth(method = "lm", alpha = 0.2, colour = "black", fullrange = TRUE) + 
  geom_point(size = 2.5, fill = "white", colour = "black", shape = 21, stroke = 1) + 
  scale_x_continuous(limits = c(min(x_low, 1), x_high * 1.1)) +
  labs(
    x = "Environmental distance", 
    y = "Genetic distance [Fst/(1-Fst)]"
  ) + 
  theme(
    axis.text.x = element_text(face = "bold", colour = "black",size = 10), 
    axis.text.y = element_text(face = "bold", colour = "black",size = 10), 
    axis.title = element_text(face = "bold", size = 12, colour = "black"),
    panel.background = element_blank(), 
    panel.border = element_rect(fill = NA)
  )
p

mantel_res
lm_model <- lm(genetic_dist ~ env_dist, data = plot_df)
summary(lm_model)
