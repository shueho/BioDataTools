#加载R包
#install.packages("microeco")
#https://github.com/ChiLiubio/microeco

#install.packages("ggpubr")
#install.packages("magrittr")
# 帮助文档1：https://chiliubio.github.io/microeco_tutorial/basic-class.html#microtable-class
# 帮助文档2：https://chiliubio.github.io/microeco_tutorial/model-based-class.html#trans_diff-class
# 源代码：https://github.com/ChiLiubio/microeco/blob/master/R/trans_diff.R

library(microeco) 
library(tidyverse)
library(magrittr)
library(ggtree)


# ==================== 参数配置 ====================
featureFile <- "input.txt"
metadataFile <- "group.txt"
groupCol <- 2
padj_flag <- 0  # P值校正控制开关，0: p_adjust_method = "none"，不进行校正；1: p_adjust_method = "fdr"，进行校正
threshold_lda <- 2  # LDA阈值
tax_sep <- ";"      # 在这里指定物种名分隔符： "|" 或 ";" 或其它
otu_prefix <- "OTU_"
group_order <- NULL # c("Yes", "No")
compatible <- 1  # 如果进化树不显示标签设置为1即可
feature_num <- 50  # 进化树标记的拉丁名个数
level <- "Genus"  # 可以填写界门纲目科属种Kingdom	Phylum	Class	Order	Family	Genus	Species

otu_raw <- read.table(featureFile, header = TRUE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)
first_col <- colnames(otu_raw)[1]
otu_ids <- paste0(otu_prefix, seq_len(nrow(otu_raw)))
otu_table <- otu_raw[, -1, drop = FALSE]
rownames(otu_table) <- otu_ids
tax_str <- otu_raw[[first_col]]
tax_raw <- data.frame(Taxonomy = tax_str, row.names = otu_ids)
tax_raw$Taxonomy <- gsub(tax_sep, ";", tax_raw$Taxonomy, fixed = TRUE)
tax_table <- data.frame(
  Kingdom = str_extract(tax_raw$Taxonomy, "k__[^;]*"),
  Phylum  = str_extract(tax_raw$Taxonomy, "p__[^;]*"),
  Class   = str_extract(tax_raw$Taxonomy, "c__[^;]*"),
  Order   = str_extract(tax_raw$Taxonomy, "o__[^;]*"),
  Family  = str_extract(tax_raw$Taxonomy, "f__[^;]*"),
  Genus   = str_extract(tax_raw$Taxonomy, "g__[^;]*"),
  Species = str_extract(tax_raw$Taxonomy, "s__[^;]*"),
  row.names = rownames(tax_raw)
)
tax_table %<>% tidy_taxonomy
group_info <- read.table(metadataFile, header = TRUE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)
sample_table <- data.frame(
  Group = group_info[[groupCol]],
  row.names = group_info[[1]]
)

dataset <- microtable$new(
  otu_table = otu_table,
  tax_table = tax_table,
  sample_table = sample_table,
  auto_tidy = FALSE
)
dataset$tidy_dataset(main_data = TRUE)
dataset$cal_abund()
dataset$save_table("01.basic_files")

diff <- trans_diff$new(
  dataset = dataset,
  method = "lefse",
  group = "Group",
  alpha = 0.05,
  taxa_level = level,
  p_adjust_method = if(padj_flag == 0) "none" else "fdr"   
)

bar_p = diff$plot_diff_bar(threshold = threshold_lda, group_order= group_order)
ggsave("02.bar_Level.pdf", bar_p, width = 8, height = 8)

errorbar_p = diff$plot_diff_abund(plot_type = "errorbar", group_order= group_order)
ggsave("03.errorbar_Level.pdf", errorbar_p, width = 8, height = 8)

barerrorbar_p = diff$plot_diff_abund(plot_type = "barerrorbar", errorbar_addpoint = FALSE, errorbar_color_black = TRUE, plot_SE = TRUE, group_order= group_order)
ggsave("04.barerrorbar_Level.pdf", barerrorbar_p, width = 8, height = 8)

ggviolin_p = diff$plot_diff_abund(plot_type = "ggviolin", coord_flip = FALSE, group_order= group_order)
ggsave("05.ggviolin_Level.pdf", ggviolin_p, width = 16, height = 8)


diff <- trans_diff$new(
  dataset = dataset,
  method = "lefse",
  group = "Group",
  alpha = 0.05,
  taxa_level = "all",
  p_adjust_method = if(padj_flag == 0) "none" else "fdr"   
)
write.csv(diff$res_diff, "06.lefse_result.csv", row.names = FALSE)

bar_p = diff$plot_diff_bar(threshold = threshold_lda, group_order= group_order)
ggsave("07.bar_All.pdf", bar_p, width = 8, height = 8)

errorbar_p = diff$plot_diff_abund(plot_type = "errorbar", group_order= group_order)
ggsave("08.errorbar_All.pdf", errorbar_p, width = 8, height = 8)

barerrorbar_p = diff$plot_diff_abund(plot_type = "barerrorbar", errorbar_addpoint = FALSE, errorbar_color_black = TRUE, plot_SE = TRUE, group_order= group_order)
ggsave("09.barerrorbar_All.pdf", barerrorbar_p, width = 8, height = 8)

ggviolin_p = diff$plot_diff_abund(plot_type = "ggviolin", coord_flip = FALSE, group_order= group_order)
ggsave("10.ggviolin_All.pdf", ggviolin_p, width = 16, height = 8)


if(compatible){patched_geom_cladelabel <- function(..., barcolour = NULL, textcolour = NULL, horizontal = NULL) {
  args <- list(...)
  if (!is.null(barcolour)) args$barcolor <- barcolour
  if (!is.null(textcolour)) args$textcolor <- textcolour
  if (!is.null(horizontal)) {
    warning("horizontal argument is no longer supported, ignored", call. = FALSE)
  }
  if(is.null(args$barcolor)) {
    args$barcolor <- NA
  }
  #args$family = "serif"
  do.call(ggtree::geom_cladelab, args)
}

assignInNamespace(
  x = "geom_cladelabel",
  value = patched_geom_cladelabel,
  ns = "ggtree"
)}
cladogram_p = diff$plot_diff_cladogram(use_feature_num = feature_num, clade_label_level = 5, group_order= group_order)
ggsave("11.cladogram.pdf", cladogram_p, width = 13, height = 8)
