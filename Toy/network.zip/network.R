#加载R包
#install.packages("microeco")
#https://github.com/ChiLiubio/microeco
#install.packages("ggpubr")
#install.packages("magrittr")
# 帮助文档1：https://chiliubio.github.io/microeco_tutorial/basic-class.html#microtable-class
# 帮助文档2：https://chiliubio.github.io/microeco_tutorial/model-based-class.html#trans_network-class
# 源代码：https://github.com/ChiLiubio/microeco/blob/master/R/trans_network.R
library(microeco) 
library(tidyverse)
library(magrittr)
library(circlize)
# 如果报错：不存在叫‘rgexf’这个名称的程序包，安装下旧版本的包
#install.packages("remotes")
#remotes::install_version("rgexf", version = "0.16.3", dependencies = FALSE)
# ==================== 参数配置 ====================
featureFile = "input.txt"
metadataFile = "group.txt"
groupCol = 2
tax_sep = ";" 
abu_thres = 0.001  #低丰度过滤，过滤在所有样品总的丰度占比低于0.1%的ASV/OTU
COR_p = 0.01  #相关性系数的显著性（或校正值）阈值，如果找不到相关OTU可以增加该值
COR_cut = NULL  #设置相关性系数的阈值，NULL自动优化阈值；指定数值如0.7为固定阈值
#COR_cut = 0.7
COR_p_adjust = "fdr"   #多重检验校正模型，设置为"none"不进行多重检验校正
cor_method = "spearman"  # 相关性系数，如果样本量大的话可以使用"pearson"，还可选"bray", "sparcc", "bicor", "cclasso", "ccrepe"

if (!is.numeric(COR_cut)) {
  COR_opt_flag <- TRUE
  COR_cut_value <- 0
} else {
  COR_opt_flag <- FALSE
  COR_cut_value <- COR_cut
}

cal_phylum_abundance <- function(net_obj, out_csv = NULL) {
  df <- net_obj$res_node_table %>%
    mutate(Phylum = sub("^p__", "", Phylum)) %>% 
    filter(!is.na(Phylum), Phylum != "")         
  
  total_otu <- nrow(df)
  
  res <- df %>%
    group_by(Phylum) %>%
    summarise(
      Sum_RelativeAbundance = sum(RelativeAbundance, na.rm = TRUE),
      OTU_Count = n(),
      .groups = "drop"
    ) %>%
    mutate(OTU_Ratio = OTU_Count / total_otu * 100) %>%
    arrange(desc(OTU_Ratio))
  
  if (!is.null(out_csv)) {
    write.csv(res, file = out_csv, row.names = FALSE)
  }
  
  return(res)
}

otu_raw <- read.table(featureFile, header = TRUE, sep = "\t", row.names = 1,check.names = FALSE, stringsAsFactors = FALSE)
tax_str <- otu_raw[, 1]
otu_table <- otu_raw[, -1, drop = FALSE]
tax_raw <- data.frame(Taxonomy = tax_str, row.names = rownames(otu_raw))
tax_raw$Taxonomy <- gsub(tax_sep, ";", tax_raw$Taxonomy, fixed = TRUE)
tax_table <- data.frame(
  Kingdom = str_extract(tax_raw$Taxonomy, "k__[^;]*"),
  Phylum  = str_extract(tax_raw$Taxonomy, "p__[^;]*"),
  Class   = str_extract(tax_raw$Taxonomy, "c__[^;]*"),
  Order   = str_extract(tax_raw$Taxonomy, "o__[^;]*"),
  Family  = str_extract(tax_raw$Taxonomy, "f__[^;]*"),
  Genus   = str_extract(tax_raw$Taxonomy, "g__[^;]*"),
  Species = str_extract(tax_raw$Taxonomy, "s__[^;]*"),
  row.names = rownames(tax_raw)
)
tax_table %<>% tidy_taxonomy
group_info <- read.table(metadataFile, header = TRUE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)
sample_table <- data.frame(
  Group = group_info[[groupCol]],
  row.names = group_info[[1]]
)
dataset <- microtable$new(
  otu_table = otu_table,
  tax_table = tax_table,
  sample_table = sample_table,
  auto_tidy = FALSE
)
net <- trans_network$new(dataset = dataset, cor_method = cor_method, filter_thres = abu_thres)
message("================ALL================")
net$cal_network(COR_p_thres = COR_p, COR_optimization = COR_opt_flag, COR_cut = COR_cut_value, COR_p_adjust = COR_p_adjust)
net$cal_module(method = "cluster_fast_greedy")
net$cal_network_attr()
write.csv(net$res_network_attr, "01.ALL_network_attr.csv", row.names = T)
net$get_edge_table()
write.csv(net$res_edge_table, "02.ALL_edge_table.csv", row.names = F)
net$get_node_table()
write.csv(net$res_node_table, "03.ALL_node_table.csv", row.names = F)
net$cal_eigen()
write.csv(net$res_eigen, "04.ALL_eigen.csv", row.names = T)
net$save_network(filepath = "05.ALL_network.gexf")
circos.clear()
pdf("06.ALL_chord_sumlinks.pdf", width = 8, height = 8)
net$plot_sum_links(method = "circlize", transparency = 0.65, annotationTrackHeight = circlize::mm_h(c(5, 5)))
dev.off()
p=net$plot_taxa_roles(use_type = 1,add_label=T,roles_color_background=T)
ggsave("07.ALL_taxa_roles.pdf", plot = p, width = 8, height = 8, device = "pdf")
cal_phylum_abundance(net, out_csv = "08.ALL_phylum_abu.csv")

group_list <- unique(dataset$sample_table$Group)
net_list <- list()
for(g in group_list){
  message(paste0("===== Start process group: ", g, " ====="))
  sub_dat <- dataset$clone()
  keep_sample <- rownames(sub_dat$sample_table)[sub_dat$sample_table$Group == g]
  sub_dat$sample_table <- sub_dat$sample_table[keep_sample, , drop = FALSE]
  sub_dat$tidy_dataset()
  t <- trans_network$new(dataset = sub_dat, cor_method = cor_method, filter_thres = abu_thres)
  # 全部统一使用全局COR_p，不额外定义分组阈值
  t$cal_network(COR_p_thres = COR_p, COR_optimization = COR_opt_flag, COR_cut = COR_cut_value, COR_p_adjust = COR_p_adjust)
  t$cal_module(method = "cluster_fast_greedy")
  t$cal_network_attr()
  write.csv(t$res_network_attr, paste0("01.",g,"_network_attr.csv"), row.names = T)
  t$get_edge_table()
  write.csv(t$res_edge_table, paste0("02.",g,"_edge_table.csv"), row.names = F)
  t$get_node_table()
  write.csv(t$res_node_table, paste0("03.",g,"_node_table.csv"), row.names = F)
  
  tryCatch({
    t$cal_eigen()
    write.csv(t$res_eigen, paste0("04.",g,"_eigen.csv"), row.names = T)
  }, error = function(e){
    message(paste0(g," eigen calculate failed: ", e$message))
  })
  
  t$save_network(paste0("05.",g,"_network.gexf"))
  
  tryCatch({
    circos.clear()
    pdf(paste0("06.",g,"_chord_sumlinks.pdf"), width = 8, height = 8)
    t$plot_sum_links(method = "circlize", transparency = 0.65, annotationTrackHeight = circlize::mm_h(c(5, 5)))
    dev.off()
    circos.clear()
  },error = function(e){
    message(paste0(g," chord plot failed: ",e$message))
    if(dev.cur()>1) dev.off()
    circos.clear()
  })
  
  role_file <- paste0("07.",g,"_taxa_roles.pdf")
  tryCatch({
    p <- t$plot_taxa_roles(use_type = 1,add_label=T,roles_color_background=T)
    ggsave(role_file, plot = p, width = 8, height = 8, device = "pdf")
  },error = function(e){
    message(paste0(g," Zi‑pi plot failed: ", e$message))
    if(file.exists(role_file)) file.remove(role_file)
  })
  
  cal_phylum_abundance(t, out_csv = paste0("08.",g,"_phylum_abu.csv"))
}
