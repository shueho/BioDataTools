# 加载包
# install.packages("tidyverse")
library(tidyverse)

# 参数配置
tbl_path     <- "merge_table.tsv"   # ASV/OTU/物种/基因原始计数丰度表路径
start_col    <- 3                   # 丰度矩阵起始列号；前start_col-1列为分类注释信息（如ASV_ID、Taxon），不参与丰度计算
prevalence_cutoff <- 0.2            # 流行度阈值；筛选在≥该比例样本中满足条件的ASV/OTU/物种/基因
abund_cutoff      <- 0.0002         # 相对丰度阈值

# 输出的文件包括
# *_source为原始计数；*_rel为相对丰度
# in_*：保留在至少prevalence_cutoff比例的样本中，样本内相对丰度大于abund_cutoff的ASV/OTU/物种/基因
# add_*：保留检出流行度≥prevalence_cutoff，且跨样本平均相对丰度大于abund_cutoff的ASV/OTU/物种/基因
# or_*：保留检出流行度≥prevalence_cutoff，或跨样本平均相对丰度大于abund_cutoff的ASV/OTU/物种/基因（满足任一条件即可）
# zero_*：不筛选，将相对丰度小于abund_cutoff的丰度值定义为0

df_raw <- read_delim(tbl_path, delim = "\t")

tax_cols <- colnames(df_raw)[1:(start_col - 1)]
sample_names <- colnames(df_raw)[start_col:ncol(df_raw)]
count_mat <- as.matrix(df_raw[, sample_names])
n_sample <- ncol(count_mat)

rel_mat <- t(t(count_mat) / colSums(count_mat))

df_rel <- cbind(df_raw[tax_cols], as.data.frame(rel_mat))
colnames(df_rel) <- c(tax_cols, sample_names)

in_flag <- rowSums(rel_mat > abund_cutoff) / n_sample >= prevalence_cutoff
write_csv(df_raw[in_flag, ], "in_source.csv")
write_csv(df_rel[in_flag, ], "in_rel.csv")

prevalence_det <- rowSums(count_mat > 0) / n_sample
mean_rel_abund <- rowMeans(rel_mat)
and_flag <- (prevalence_det >= prevalence_cutoff) & (mean_rel_abund > abund_cutoff)
write_csv(df_raw[and_flag, ], "and_source.csv")
write_csv(df_rel[and_flag, ], "and_rel.csv")

or_flag <- (prevalence_det >= prevalence_cutoff) | (mean_rel_abund > abund_cutoff)
write_csv(df_raw[or_flag, ], "or_source.csv")
write_csv(df_rel[or_flag, ], "or_rel.csv")

rel_mat_zero <- rel_mat
rel_mat_zero[rel_mat_zero < abund_cutoff] <- 0

count_mat_zero <- count_mat
count_mat_zero[rel_mat < abund_cutoff] <- 0

df_rel_zero   <- cbind(df_raw[tax_cols], as.data.frame(rel_mat_zero))
df_count_zero <- cbind(df_raw[tax_cols], as.data.frame(count_mat_zero))
colnames(df_rel_zero)   <- c(tax_cols, sample_names)
colnames(df_count_zero) <- c(tax_cols, sample_names)

write_csv(df_count_zero, "zero_source.csv")
write_csv(df_rel_zero,   "zero_rel.csv")
