# install.packages(c("ggplot2", "ggforce"))
library(ggplot2)
library(ggforce)

Stress_value <-  0.079
RSQ_value    <- 0.969
MDS <- "MDS.txt"
margin <- 0.5


df <- read.delim(MDS, sep = "\t", header = TRUE)
x_min <- min(df$d1) - margin
x_max <- max(df$d1) + margin
y_min <- min(df$d2) - margin
y_max <- max(df$d2) + margin
p <- ggplot(df, aes(x = d1, y = d2, color = group)) +
  geom_mark_ellipse(
    fill = NA,
    linetype = 2,
    size = 1,
    conf.level = 0.95
  ) +
  geom_point(size = 3, shape = 19) +
  geom_text(aes(label = site), nudge_x = 0.07, nudge_y = 0.07, size = 3) +
  labs(
    x = "Dimension 1",
    y = "Dimension 2",
    color = "Group"
  ) +
  xlim(x_min, x_max) +
  ylim(y_min, y_max) +
  theme_bw() +
  theme(
    panel.border = element_rect(linewidth = 1),
    axis.line = element_blank(),
    axis.ticks = element_line(linewidth = 0.8),
    axis.title = element_text(size = 13),
    axis.text  = element_text(size = 11),
    legend.title = element_text(size = 12),
    legend.text  = element_text(size = 11),
    plot.margin = margin(12, 45, 12, 12),
    panel.grid = element_blank()
  ) +
  annotate(
    "label",
    x = x_max - 0.12, y = y_max - 0.09,
    label = paste0("Stress = ", Stress_value, "\nRSQ = ", RSQ_value),
    size = 3.8, fill = "white", alpha = 0.9
  )

print(p)

ggsave("MDS_plot.pdf", p, width = 10.5, height = 6.8, dpi = 600)
#ggsave("MDS_plot.png", p, width = 10.5, height = 6.8, dpi = 600)