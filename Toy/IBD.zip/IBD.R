pkgs <- c("ggplot2", "vegan")
new_pkgs <- pkgs[!(pkgs %in% installed.packages()[,"Package"])]
if(length(new_pkgs) > 0) install.packages(new_pkgs)

library(ggplot2)
library(vegan)

fst_path <- "fst.txt"
geo_path <- "geo.txt"
perm_num <- 10000

raw_fst <- read.csv(fst_path, header = FALSE, sep = "\t")
raw_geo <- read.csv(geo_path, header = FALSE, sep = "\t")

trans_fst <- raw_fst / (1 - raw_fst)
trans_geo <- log10(raw_geo)

mat_fst <- as.matrix(trans_fst)
mat_geo <- as.matrix(trans_geo)
dist_fst <- as.dist(mat_fst)
dist_geo <- as.dist(mat_geo)

mantel_res <- mantel(dist_fst, dist_geo, method = "spearman", permutations = perm_num, na.rm = TRUE)
mantel_res

vec_genetic <- as.vector(dist_fst)
vec_geographic <- as.vector(dist_geo)
plot_df <- data.frame(geo_dist = vec_geographic, genetic_dist = vec_genetic)

x_low <- min(plot_df$geo_dist, na.rm = TRUE)
x_high <- max(plot_df$geo_dist, na.rm = TRUE)

p <- ggplot(plot_df, aes(x = geo_dist, y = genetic_dist)) + 
  geom_smooth(method = "lm", alpha = 0.2, colour = "black", fullrange = TRUE) + 
  geom_point(size = 2.5, fill = "white", colour = "black", shape = 21, stroke = 1) + 
  scale_x_continuous(limits = c(min(x_low, 1), x_high * 1.1)) +
  labs(
    x = "Geographic distance (log)", 
    y = "Genetic distance [Fst/(1-Fst)]"
  ) + 
  theme(
    axis.text.x = element_text(face = "bold", colour = "black",size = 10), 
    axis.text.y = element_text(face = "bold", colour = "black",size = 10), 
    axis.title = element_text(face = "bold", size = 12, colour = "black"),
    panel.background = element_blank(), 
    panel.border = element_rect(fill = NA)
  )
p

lm_model <- lm(genetic_dist ~ geo_dist, data = plot_df)
summary(lm_model)
