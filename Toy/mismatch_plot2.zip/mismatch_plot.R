if (!require(ggplot2)) install.packages("ggplot2")
if (!require(patchwork)) install.packages("patchwork")
if (!require(dplyr)) install.packages("dplyr")

library(ggplot2)
library(patchwork)
library(dplyr)

## ========== 配置区 ==========
curve_source = "Model"   
#curve_source = "Simulated"

y_type = "frequency"    
#y_type = "count" 
# ==========================================================

df <- read.delim("mismatch.txt", header = TRUE, sep = "\t")

df_plot <- df %>%
  mutate(
    obs_val = if(y_type == "frequency") Observed / Total else Observed,
    sim_val = if(y_type == "frequency") Simulated / Total else Simulated,
    mod_val = if(y_type == "frequency") Model / Total else Model
  ) %>%
  mutate(
    Expected = case_when(
      curve_source == "Simulated" ~ sim_val,
      curve_source == "Model" ~ mod_val
    )
  )

y_title <- if(y_type == "frequency") "Frequency" else "Count"
fmt_str <- if(y_type == "frequency") "%.2f" else "%.0f"

plot_group <- function(d, name) {
  max_x <- max(d$Differences, na.rm = TRUE)
  max_y <- max(c(d$obs_val, d$Expected), na.rm = TRUE)
  
  ggplot(d, aes(x = Differences)) +
    geom_line(aes(y = obs_val, color = "Observed"), 
              linewidth = 0.9, linetype = "11") +
    geom_point(aes(y = obs_val, color = "Observed"), 
               fill = "white", shape = 21, size = 1.1, stroke = 0.8) +
    geom_line(aes(y = Expected, color = "Expected"), 
              linewidth = 0.8) +
    labs(x = "Pairwise differences", y = y_title, color = NULL) +
    scale_y_continuous(
      labels = function(x) sprintf(fmt_str, x),
      expand = c(0.02, 0)
    ) +
    theme_bw(base_size = 14) +
    theme(
      text = element_text(family = "serif", face = "plain"),
      panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.6),
      axis.line = element_line(colour = "black", linewidth = 0.5),
      axis.title = element_text(size = 14),
      axis.text = element_text(size = 12, color = "black"),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      plot.margin = margin(8, 8, 8, 8),
      legend.position = "none"   
    ) +
    geom_text(
      data = data.frame(x = max_x, y = max_y, lab = name),
      aes(x = x, y = y, label = lab),
      inherit.aes = FALSE,
      hjust = 1.05,
      vjust = 1.05,
      family = "serif",
      size = 5,
      fontface = "bold.italic"
    )
}

plots <- lapply(unique(df_plot$group), function(g) {
  sub_data <- subset(df_plot, group == g)
  plot_group(sub_data, g)
})

final_plot <- wrap_plots(plots, ncol = 2) +
  plot_layout(guides = "collect")

final_plot <- final_plot &
  scale_color_manual(
    values = c("Observed" = "#2166AC", "Expected" = "#D6604D"),
    breaks = c("Observed", "Expected"),
    guide = guide_legend(
      override.aes = list(
        linetype = c("11", "solid"),
        shape = c(21, NA),
        fill = c("white", NA)
      ),
      nrow = 1,
      title = NULL
    )
  ) &
  theme(
    legend.position = "top",
    legend.direction = "horizontal",
    legend.background = element_blank(),
    legend.key = element_blank(),
    legend.text = element_text(family = "serif", size = 12),
    legend.key.width = unit(1.8, "cm"),   
    legend.key.height = unit(0.6, "cm"),  
    plot.margin = margin(12, 5, 5, 5)
  )

print(final_plot)
ggsave(filename = "mismatch_plot.pdf", plot = final_plot, width = 8.98, height = 5.88, units = "in")