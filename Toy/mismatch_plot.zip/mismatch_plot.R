if (!require(ggplot2)) install.packages("ggplot2")
if (!require(patchwork)) install.packages("patchwork")

library(ggplot2)
library(patchwork)

df <- read.delim("mismatch.txt", header = TRUE, sep = "\t")

df$Differences <- as.numeric(trimws(df$Differences))
df$Observed   <- as.numeric(trimws(df$Observed))
df$Expected   <- as.numeric(trimws(df$Expected))

plot_group <- function(d, name) {
  max_x <- max(d$Differences, na.rm = TRUE)
  max_y <- max(c(d$Observed, d$Expected), na.rm = TRUE)
  
  ggplot(d, aes(x = Differences)) +
    geom_line(aes(y = Observed, color = "Observed"), 
              linewidth = 0.9, linetype = "11") +
    geom_point(aes(y = Observed, color = "Observed"), 
               fill = "white", shape = 21, size = 1.1, stroke = 0.8) +
    geom_line(aes(y = Expected, color = "Expected"), 
              linewidth = 0.8) +
    labs(x = "Pairwise differences", y = "Frequency", color = NULL) +
    scale_y_continuous(
      labels = function(x) sprintf("%.2f", x),
      expand = c(0.02, 0)
    ) +
    theme_bw(base_size = 14) +
    theme(
      text = element_text(family = "serif", face = "plain"),
      panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.6),
      axis.line = element_line(colour = "black", linewidth = 0.5),
      axis.title = element_text(size = 14),
      axis.text = element_text(size = 12, color = "black"),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      plot.margin = margin(8, 8, 8, 8),
      legend.position = "none"   
    ) +
    geom_text(
      data = data.frame(x = max_x, y = max_y, lab = name),
      aes(x = x, y = y, label = lab),
      inherit.aes = FALSE,
      hjust = 1.3,
      vjust = 1.3,
      family = "serif",
      size = 5,
      fontface = "bold.italic"
    )
}

plots <- lapply(unique(df$group), function(g) plot_group(subset(df, group == g), g))

final_plot <- wrap_plots(plots, ncol = 2) +
  plot_layout(guides = "collect")

final_plot <- final_plot &
  scale_color_manual(
    values = c("Observed" = "#2166AC", "Expected" = "#D6604D"),
    breaks = c("Observed", "Expected"),
    guide = guide_legend(
      override.aes = list(
        linetype = c("11", "solid"),
        shape = c(21, NA),
        fill = c("white", NA)
      ),
      nrow = 1,
      title = NULL
    )
  ) &
  theme(
    legend.position = "top",
    legend.direction = "horizontal",
    legend.background = element_blank(),
    legend.key = element_blank(),
    legend.text = element_text(family = "serif", size = 12),
    legend.key.width = unit(1.8, "cm"),   
    legend.key.height = unit(0.6, "cm"),  
    plot.margin = margin(12, 5, 5, 5)
  )

print(final_plot)

ggsave(filename = "mismatch_plot.pdf",plot = final_plot,width = 8.98,height = 5.88,units = "in")
